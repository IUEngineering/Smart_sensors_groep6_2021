#include <Wire.h>
#include "Adafruit_SGP40.h"

Adafruit_SGP40 sgp;


void setup() {
  pinMode(8, OUTPUT);    // sets the digital pin 9 as output
  Serial.begin(115200);
  while (!Serial) { delay(10); } // Wait for serial console to open!

  Serial.println("SGP40 test");

  if (! sgp.begin()){
    Serial.println("Sensor not found :(");
    while (1);
  }
  Serial.print("Found SGP40 serial #");
  Serial.print(sgp.serialnumber[0], HEX);
  Serial.print(sgp.serialnumber[1], HEX);
  Serial.println(sgp.serialnumber[2], HEX);
}

int counter = 0;
void loop() {
  uint16_t raw;
  
  raw = sgp.measureRaw() - 20000;

  Serial.print("Measurement: ");
  Serial.println(raw);
  delay(1000);
  if (raw < 10000){
    digitalWrite(8, HIGH); 
  }
  else{
    digitalWrite(8, LOW);
    }
}