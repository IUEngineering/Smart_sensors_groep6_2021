#define  F_CPU 32000000UL

#include <avr/io.h>
#include <util/delay.h>
#include "CLK/clock.h"
#include <avr/interrupt.h>

#define LOCK_PERIOD_MS 7500

void init_adc(void)
{
	PORTA.DIRCLR     = PIN2_bm;                          // configure PA2 as input for ADCA
	ADCA.CH0.MUXCTRL = ADC_CH_MUXPOS_PIN2_gc;            // PA2 to channel 0
	ADCA.CH0.CTRL    = ADC_CH_INPUTMODE_SINGLEENDED_gc;  // channel 0 single-ended
	ADCA.REFCTRL     = ADC_REFSEL_INTVCC_gc;             // internal VCC/1.6 reference
	ADCA.CTRLB       = ADC_RESOLUTION_12BIT_gc;          // 12 bits conversion, unsigned, no freerun
	ADCA.PRESCALER   = ADC_PRESCALER_DIV256_gc;           // 32MHz/256 = 125kHz
	ADCA.CTRLA       = ADC_ENABLE_bm;                    // enable adc
}

uint16_t read_adc(void)
{
	uint16_t res;

	ADCA.CH0.CTRL |= ADC_CH_START_bm;                    // start ADC conversion
	while ( !(ADCA.CH0.INTFLAGS & ADC_CH_CHIF_bm) ) ;    // wait until it's ready
	res = ADCA.CH0.RES;
	ADCA.CH0.INTFLAGS |= ADC_CH_CHIF_bm;                 // reset interrupt flag

	return res;                                          // return measured value
}

int button_open(void) {
	if (bit_is_clear(PORTD.IN,PIN3_bp) ) {
		if (bit_is_clear(PORTD.IN,PIN3_bp) )
		return 1;
	}
	return 0;
}

int button_close(void) {
	if (bit_is_clear(PORTD.IN,PIN2_bp) ) {
		if (bit_is_clear(PORTD.IN,PIN2_bp) )
		return 1;
	}
	return 0;
}

int hall_effect(void) {
	if(bit_is_clear(PORTD.IN,PIN6_bp)){
		if(bit_is_clear(PORTD.IN,PIN6_bp))
		return 1;
	}
	return 0;
}

int spg40_arduino_in(void) {
	if(bit_is_clear(PORTD.IN,PIN7_bp)){
		if(bit_is_clear(PORTD.IN,PIN7_bp))
		return 1;
	}
	return 0;
}

void open_window(void){
	if (!hall_effect()){
		PORTD.OUTCLR = PIN4_bm;          // toggles output MOTOR-F
		_delay_ms(LOCK_PERIOD_MS);
		
	}
}

void close_window(void){
	if(hall_effect()){          
		PORTD.OUTCLR = PIN5_bm;				// toggles output MOTOR-B
		_delay_ms(LOCK_PERIOD_MS);			// lock input
	}
}

int main(void)
{
	init_clock();
	
	PORTD.DIRCLR   = PIN2_bm;            // input pin switch D2
	PORTD.DIRCLR   = PIN3_bm;            // input pin switch D3
	PORTD.DIRSET   = PIN4_bm;            // output pin MOTOR-F
	PORTD.DIRSET   = PIN5_bm;            // output pin MOTOR-B
	PORTD.DIRCLR   = PIN6_bm;            // input pin hall effect D6
	PORTD.DIRCLR   = PIN7_bm;            // input pin SGP40 arduino D7		
	PORTD.PIN3CTRL = PORT_OPC_PULLUP_gc; // enable pull up pin D3
	PORTD.PIN2CTRL = PORT_OPC_PULLUP_gc; // enable pull up pin D2
	
	PORTD.OUTSET = PIN4_bm;
	PORTD.OUTSET = PIN5_bm;
	
	float MAX_VALUE =  4095;
	float VCC       =  3.30;
	float VREF      =  (((double) VCC) / 1.6);  // is 2.06125
	float VOFFSET   =   ((0.05)*(VREF))      ; // is 0.103125
	uint16_t res;
	double vinp;
	double T;
	init_adc();
	sei();
	
	while (1) {
		res  = read_adc();
		vinp  = ((double) res) * VREF / (MAX_VALUE + 1) - VOFFSET;           // formula 20.7
		T = ((8.194 - sqrt (pow(-8.194,2) + 4 * 0.00262 * (1324 - vinp*1000)))/(2 * -0.00262))+30;
		
		PORTD.OUTSET = PIN4_bm;
		PORTD.OUTSET = PIN5_bm;
		
		PORTF.DIRSET = PIN1_bm; //G
		
		if (button_open()) {
			open_window();
		}
		if (button_close() || T<=18) {
			close_window();
		}
		if (T >= 29){  //add && nrf_read 1
			open_window();
		}
		if (spg40_arduino_in() && T>=18){ //add && nrf_read 1
			open_window();
		}
	}
}

